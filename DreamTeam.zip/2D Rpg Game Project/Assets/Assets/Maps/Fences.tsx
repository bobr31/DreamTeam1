<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Fences" tilewidth="16" tileheight="16" tilecount="96" columns="8">
 <image source="../Art/Fence.png" width="128" height="192"/>
 <tile id="24">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.0909" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0.0909091" width="16.0909" height="16"/>
  </objectgroup>
 </tile>
 <tile id="26">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="40">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="42">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="72">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.1818" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="73">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.2727" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="74">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="80">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="88">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="16.0909" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="90">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.181818" width="16.1818" height="16.1818"/>
  </objectgroup>
 </tile>
</tileset>
