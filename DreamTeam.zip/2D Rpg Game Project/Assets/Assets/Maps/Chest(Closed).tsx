<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Chest(Closed)" tilewidth="16" tileheight="16" tilecount="24" columns="8">
 <image source="../Art/Chest0.png" width="128" height="48"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="1" x="0.727273" y="3.72727" width="14.4545" height="10.4545"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index">
   <object id="1" x="0.92" y="2" width="14.0909" height="12.7273"/>
  </objectgroup>
 </tile>
 <tile id="8">
  <objectgroup draworder="index">
   <object id="1" x="2.09091" y="0.818182" width="11.9091" height="15.1818"/>
  </objectgroup>
 </tile>
</tileset>
