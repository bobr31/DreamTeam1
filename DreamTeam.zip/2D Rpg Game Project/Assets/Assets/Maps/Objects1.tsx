<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Objects1" tilewidth="16" tileheight="16" tilecount="176" columns="8">
 <image source="../Art/Decor0.png" width="128" height="352"/>
 <tile id="24">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.0909" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index">
   <object id="1" x="0.0909091" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="32">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.1818" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="33">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.0909" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="34">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.2727" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="35">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16.0909" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="36">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="16.0909" height="16"/>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16.2727" height="16.3636"/>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.181818" width="16.2727" height="16.2727"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index">
   <object id="1" x="-0.0625" y="0" width="16.0625" height="16.0625"/>
  </objectgroup>
 </tile>
 <tile id="41">
  <objectgroup draworder="index">
   <object id="3" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="43">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="46">
  <objectgroup draworder="index">
   <object id="1" x="-0.181818" y="0" width="16.2727" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="47">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="15.9091" height="16"/>
  </objectgroup>
 </tile>
 <tile id="56">
  <objectgroup draworder="index">
   <object id="1" x="2" y="0" width="12.1818" height="15.8182"/>
  </objectgroup>
 </tile>
 <tile id="57">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.818182" width="16.0909" height="14.1818"/>
  </objectgroup>
 </tile>
 <tile id="58">
  <objectgroup draworder="index">
   <object id="1" x="2" y="0" width="11.9091" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="59">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="15.9091" height="16"/>
  </objectgroup>
 </tile>
 <tile id="60">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="61">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="62">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="15.9091" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="72">
  <objectgroup draworder="index">
   <object id="1" x="0.909091" y="-0.0909091" width="14.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="73">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.818182" width="16" height="14.0909"/>
  </objectgroup>
 </tile>
 <tile id="74">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="75">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.181818" width="16" height="15.8182"/>
  </objectgroup>
 </tile>
 <tile id="80">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.1818" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="81">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.1818" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="82">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="83">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="15.9091" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="84">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="85">
  <objectgroup draworder="index">
   <object id="1" x="0.0909091" y="0.0909091" width="15.8182" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="86">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="16.0909" height="16"/>
  </objectgroup>
 </tile>
 <tile id="87">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="89">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.0909" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="94">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16.0909" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="136">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="137">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.0909" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="138">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="139">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="140">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="15.9091" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="144">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="145">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="146">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="15.9091" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="147">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.0909" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="148">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="168">
  <objectgroup draworder="index">
   <object id="1" x="-0.363636" y="-0.363636" width="16.3636" height="16.5455"/>
  </objectgroup>
 </tile>
</tileset>
