<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Objects2" tilewidth="16" tileheight="16" tilecount="432" columns="12">
 <image source="../Art/Tree0.png" width="192" height="576"/>
 <tile id="36">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16.0909" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="37">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="16.0909" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="38">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="39">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="45">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="48">
  <objectgroup draworder="index">
   <object id="1" x="0.0909091" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
 <tile id="50">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.0909" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="60">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0.0909091" width="16.0909" height="15.8182"/>
  </objectgroup>
 </tile>
 <tile id="61">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="62">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="14.8182" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="75">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="81">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.0909" height="15.9091"/>
  </objectgroup>
 </tile>
 <tile id="111">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.181818" width="16.0909" height="16.2727"/>
  </objectgroup>
 </tile>
 <tile id="147">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="0" width="16.0909" height="16"/>
  </objectgroup>
 </tile>
 <tile id="183">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16" height="16.0909"/>
  </objectgroup>
 </tile>
 <tile id="219">
  <objectgroup draworder="index">
   <object id="1" x="0" y="-0.0909091" width="16" height="16.1818"/>
  </objectgroup>
 </tile>
 <tile id="333">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16.0625" height="16"/>
  </objectgroup>
 </tile>
 <tile id="363">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16"/>
  </objectgroup>
 </tile>
</tileset>
