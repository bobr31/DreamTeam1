<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Pillars" tilewidth="16" tileheight="16" tilecount="3" columns="1">
 <image source="../Art/Pillar.png" width="16" height="48"/>
 <tile id="2">
  <objectgroup draworder="index">
   <object id="1" x="-0.0909091" y="-0.0909091" width="16.1818" height="16.0909"/>
  </objectgroup>
 </tile>
</tileset>
