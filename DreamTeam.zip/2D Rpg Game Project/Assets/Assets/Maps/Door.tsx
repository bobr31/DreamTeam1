<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Door" tilewidth="16" tileheight="16" tilecount="48" columns="8">
 <image source="../Art/Door0.png" width="128" height="96"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="1" x="0" y="0" width="16" height="16.1818"/>
  </objectgroup>
 </tile>
</tileset>
