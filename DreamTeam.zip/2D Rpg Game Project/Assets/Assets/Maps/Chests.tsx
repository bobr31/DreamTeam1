<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.0" name="Chests" tilewidth="16" tileheight="16" tilecount="24" columns="8">
 <image source="../Art/Chest1.png" width="128" height="48"/>
 <tile id="0">
  <objectgroup draworder="index">
   <object id="1" x="1" y="1.09091" width="15.1818" height="13.0909"/>
  </objectgroup>
 </tile>
 <tile id="1">
  <objectgroup draworder="index">
   <object id="1" x="0.818182" y="1.63636" width="15.2727" height="13.5455"/>
  </objectgroup>
 </tile>
</tileset>
